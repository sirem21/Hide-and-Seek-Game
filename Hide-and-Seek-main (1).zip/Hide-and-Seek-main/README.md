# Hide and Seek Game Project made with QtCreator

There are 2 versions of the Hide-and-Seek game. 
In first version, players play the game simultaneously. There are 7 ghosts and the player who finds more ghosts than the other player wins. There are no time limit in this version, so all ghosts have to be found to end the game.
In second version, players play the game one by one with limited time. The player who finds more ghosts in 30 seconds wins the game.
Here's the gameplay of the project:



https://github.com/Caglyn/CENG206-Project2-Group-9/assets/126319075/409f2080-f624-4bac-941c-ac98e32e8927

